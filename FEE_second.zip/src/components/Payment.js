import React from 'react'

export default function Payment() {
  return (
    <div className='Payment'>
        <img src='./pay.png' height={700} width={400} alt='not found'/>
    </div>
  )
}
